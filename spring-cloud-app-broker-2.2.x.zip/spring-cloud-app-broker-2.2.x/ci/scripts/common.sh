source /opt/concourse-java.sh
export TERM=xterm-256color
setup_symlinks
