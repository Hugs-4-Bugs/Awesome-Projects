package com.example.springSmstrigger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSmstriggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSmstriggerApplication.class, args);
	}

}
