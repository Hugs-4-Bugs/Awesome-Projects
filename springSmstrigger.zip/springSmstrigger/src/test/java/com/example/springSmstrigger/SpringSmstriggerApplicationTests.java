package com.example.springSmstrigger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSmstriggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
