package UserinterfaceLayer;

import javafx.event.ActionEvent;

public class ReviewAppController
{
    public void rejectApplication(ActionEvent actionEvent)
    {
    }

    public void acceptApplication(ActionEvent actionEvent)
    {
    }
}
