

package BusinessLogicLayer;

public class Account {

    private String accountNo;
    public Account()
    {

    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public Account(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountNo() {
        return accountNo;
    }

}
