package com.example.bitcoinmining.service;

import com.example.bitcoinmining.model.User;

public interface UserService {
    User registerUser(User user);
    // Add more user service methods as needed

	void registerUser(String username, String encodedPassword);
}
