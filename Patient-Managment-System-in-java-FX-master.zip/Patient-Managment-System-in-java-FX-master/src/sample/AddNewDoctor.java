package sample;

public class AddNewDoctor
{
}
