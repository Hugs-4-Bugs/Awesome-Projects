package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.awt.event.ActionEvent;

public class Admin {

    @FXML
    private Button AddNewPatient;

    @FXML
    void handelAction(ActionEvent event) {

    }

}

