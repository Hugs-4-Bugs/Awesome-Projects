package sample;

public class AddNewPatient
{
}
