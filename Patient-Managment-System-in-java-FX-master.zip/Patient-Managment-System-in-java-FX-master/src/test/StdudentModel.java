package test;

public class StdudentModel {
}
