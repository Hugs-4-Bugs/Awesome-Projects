package BusinessLogicLayer;

public class Manager
{
//    public static int getPatientID()//working
//    {
//        return Database.getPatientID();
//
//    }
//
//    public static void sendTodataBase(String name, String dis)//working
//    {
//        Database.insertDisease(name, dis);
//
//    }
//
//    public static void insertDoctor(String name, String disease)//working
//    {
//        Database.insertDoctor(name, disease);
//
//    }
//
//    public static String[][] searchPatientRecord(String name, String Fname)//working
//    {
//        return Database.searchPatientRecord(name, Fname);
//
//    }
//
//    public static void searchPatientByDisease(String name)
//    {
//        Database.searchPatientByDisease(name);
//
//    }
//
//    public static String[][] searchPatientByID(int id)//working
//    {
//        return Database.searchPatientByID(id);
//
//    }
//
//    public static String[][] searchPatientByNAME(String name)//working
//    {
//        return Database.searchPatientByNAME(name);
//
//    }
//
//    public static void searchPatientByAge(String name)
//    {
//        //Database.searchPatientByAge(name);
//
//    }
//
//    //working
//    public static void insertPatient(int id, String name, String fathername, String doctor, String dHistroy, String discription, String gender, Date date)
//    {
//        Database.insertPatient(id, name, fathername, doctor, dHistroy, discription, gender, date);
//
//    }
//
//    public static void deletePatient(String name, String fname)//working
//    {
//        Database.deletePatient(name, fname);
//
//    }
//
//    public static String[] diseaselist()//working
//    {
//        return Database.diseaseList();
//
//    }
//
//    public static void searchPatientByDoctor(String name)
//    {
//        Database.searchPatientByDoctor(name);
//
//    }

}
