# Patient-Managment-System-in-java-FX

<p>This project is Developed in pure java language and java FX technologies. 
Front-end developed in java FXML and back-end debveloped in java lnguage. And mySQL database is used to store data.</p>

<h3>Features</h3>

<ul>
<li>Multipal Users of system (Admin, Guest, computer operator etc).</li>
<li>admin can Manage Doctor records. </li>
<li>computer operator can manage Patient and disease records.</li></ul>

<h4>Click play button to view Demo video of project.<h4/>
  
  <a href="https://www.youtube.com/watch?v=3-L3c0RB8qM" target="_blank"><img src="assets/FX.PNG" 
alt="Click Image to play video" width="600" height="300" border="10" /></a>
  

<h3>Screen shorts</h3>
  
  Login
  
<img src="assets/loginFx.PNG" width="600" height="400">
 
 Add new Doctor.
 
 <img src="assets/addDoctor.PNG" width="1000" height="400">
 
 Insert a new Patient.
 
 <img src="assets/addpatientFX.PNG" width="1000" height="400">
 
 Change Forgotton password.
 
 <img src="assets/forget password.PNG" width="500" height="400">
 
 Search Doctor By Name
 
 <img src="assets/searchDoctorByName.PNG" width="1000" height="400">

search Patient

<img src="assets/searchpatient.PNG" width="1000" height="400">

Create a new user

<img src="assets/signup.PNG" width="600" height="400">
