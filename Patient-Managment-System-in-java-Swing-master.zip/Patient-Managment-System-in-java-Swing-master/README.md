# Patient-Managment-System-in-java-Swing

<p>This project is Developed in pure java language and java Swing technologies. 
Front-end developed in java swing and back-end debveloped in java lnguage. And mySQL database is used to store data.</p>

<h3>Features</h3>
<ul>
<li>Multipal Users of system (Admin, Guest, computer operator etc).</li>
<li>admin can Manage Doctor records. </li>
<li>computer operator can manage Patient and disease records.</li></ul>

<h4>CLick play button to view demo video<h4/>
  
  <a href="https://www.youtube.com/watch?v=J-ZZ-9TvuqE" target="_blank"><img src="assets/Swing.PNG" 
alt="Click Image to play video" width="600" height="400" border="10" /></a>
  

<h3>Screen shorts</h3>
  
  Login
  
<img src="assets/login.PNG" width="500" height="400">
 
 Manage Record Menu
 
 <img src="assets/managerecord.PNG" width="600" height="400">
 
 Search Patient.
 
 <img src="assets/search.PNG" width="600" height="400">
 
 Search Doctor
 
 <img src="assets/searchdoctor.PNG" width="600" height="400">
 
 Search Menu
 
 <img src="assets/searchmenu.PNG" width="700" height="400">

Add Patient

<img src="assets/addpatient.PNG" width="800" height="500">

Insert Doctor

<img src="assets/insertdoctor.PNG" width="900" height="400">
